﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Navegador;
using System.Data.Odbc;
using SeguridadGrafico;
using Seguridad;
using Filtrado;
using ConexionODBC;

namespace dllClientes
{
    public partial class frmNuevoCliente : Form
    {
        string sCod;
        string estado = "";
        public frmNuevoCliente()
        {
            InitializeComponent();
        }

        public frmNuevoCliente(string cod, string vendedor, string cobrador, string nombre, string apellido, string direccion, string telefono, string correo, string estado)
        {
            InitializeComponent();


            lbCod.Text = cod;
            cbVendedor.Text = vendedor;
            cbCobrador.Text = cobrador;
            txtBoxNombre.Text = nombre;
            txtApellido.Text = apellido;
            txtDireccion.Text = direccion;
            txtTelefono.Text = telefono;
            txtBoxCorreo.Text = correo;
           // txtNit.Text = nit;
            txt3.Text = estado;
           



        }
        public void llenarCombos() {

            OdbcCommand _comando2 = new OdbcCommand(String.Format(

            "SELECT CONCAT(icod,' ',vtipo)  AS tipo , icod FROM matipocliente"), ConexionODBC.Conexion.ObtenerConexion());
            OdbcDataReader _reader2 = _comando2.ExecuteReader();
            cbPrueba.Items.Clear();

            while (_reader2.Read())
            {

                cbPrueba.Items.Add(_reader2[0].ToString());
                txt1.Text = _reader2["icod"].ToString();

            }
            _reader2.Close();
            cbPrueba.Text = "";

        
            OdbcCommand _comando = new OdbcCommand(String.Format(

            "SELECT CONCAT(codVendedor,' ',nombrevendedor, ' ', ' ',apellidovendedor)  AS campos , codVendedor FROM vendedor"), ConexionODBC.Conexion.ObtenerConexion());
            OdbcDataReader _reader = _comando.ExecuteReader();
            cbVendedor.Items.Clear();
         
            while (_reader.Read())
            {
               
                cbVendedor.Items.Add(_reader[0].ToString());
                txt2.Text = _reader["codVendedor"].ToString();
              
            }
            _reader.Close();
            cbVendedor.Text = "";



            OdbcCommand comando1 = new OdbcCommand(String.Format(

          "SELECT CONCAT(codCobrador,' ',nombre, ' ', ' ',apellido)  AS cobrar ,codCobrador FROM cobrador"), ConexionODBC.Conexion.ObtenerConexion());
            OdbcDataReader reader1 = comando1.ExecuteReader();
            cbCobrador.Items.Clear();

            while (reader1.Read())
            {

                cbCobrador.Items.Add(reader1[0].ToString());
                txt3.Text = reader1["codCobrador"].ToString();

            }
            reader1.Close();

            cbCobrador.Text = "";
        }
        
       
        public void funDetalleCliente(){
            
            OdbcCommand _comando = new OdbcCommand(String.Format("SELECT total FROM FACTURA WHERE ncodcliente ='"+lbCod.Text+"'"),ConexionODBC.Conexion.ObtenerConexion());
            OdbcDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {

                lbSaldoActual.Text = _reader["total"].ToString();
              
            }
            _reader.Close();
         


            OdbcCommand comando = new OdbcCommand(String.Format("SELECT monto FROM CUENTASCORRIENTESCLIENTES WHERE ncodcliente ='"+lbCod.Text+"'"),ConexionODBC.Conexion.ObtenerConexion());
            OdbcDataReader reader = comando.ExecuteReader();
            while (reader.Read())
            {

                txtSaldo.Text = reader["monto"].ToString();
              
            }
       
            _reader.Close();
           string  mostrarSaldo = lbSaldoActual.Text + txtSaldo.Text;
           lbAbono.Text = mostrarSaldo.ToString();
            string formatoFecha="yyyy/mm/10";
            DateTime.Now.ToString("yyyy/MM/dd");
            string guardaFecha =  DateTime.Now.ToString("yyyy/MM/dd");
            if(guardaFecha.ToString() == formatoFecha.ToString() ){
             //int abono = txtSaldo.ToString * 0.05;
            
            }
            
            
         }
    
        

        private void frmNuevoCliente_Load(object sender, EventArgs e)
        {
            llenarCombos();
            txtBoxNombre.Enabled = false;
            txtApellido.Enabled = false;
            txtBoxCorreo.Enabled = false;
            txtDireccion.Enabled = false;
            txtNit.Enabled = false;
            txt3.Enabled = false;
            txtDireccion.Enabled = false;
            txtTelefono.Enabled = false;
            txt4.Enabled = false;
            cbPrueba.Enabled = false;
            cbVendedor.Enabled = false;
            cbCobrador.Enabled = false;
            cmbEstado.Enabled = false;
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            txtBoxNombre.Enabled = true;
            txtApellido.Enabled = true;
            txtBoxCorreo.Enabled = true;
            txtDireccion.Enabled = true;
            txtNit.Enabled = true;
            txt3.Enabled = true;
            txtDireccion.Enabled = true;
            txtTelefono.Enabled = true;
            txt4.Enabled = true;
            cbPrueba.Enabled = true;
            cbVendedor.Enabled = true;
            cbCobrador.Enabled = true;
            cmbEstado.Enabled = true;

           


        }

        private void button5_Click(object sender, EventArgs e)
        {
            clasnegocio cn = new clasnegocio();
            Boolean bPermiso = true;
          

            if (estado.Equals("editar"))
            {

                TextBox[] aDatosEdit = { txtBoxNombre, txtApellido, txtBoxCorreo, txtDireccion, txtNit, txt3, txtDireccion, txtTelefono, txt4 };
                string sTabla = "cliente";
                string sCodigo = "ncodcliente";

                cn.EditarObjetos(sTabla, bPermiso, aDatosEdit, sCod, sCodigo);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Editar", sTabla);
                this.Close();


            }
            else if (estado.Equals("eliminar"))
            {
                string sTabla = "cliente";
                string sCampoLlavePrimaria = "ncodcliente";
                string sCampoEstado = "condicion";
                //System.Console.WriteLine("----" + sCod);
                cn.funeliminarRegistro(sTabla, sCod, sCampoLlavePrimaria, sCampoEstado);
                claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Eliminar", sTabla);
                this.Close();
            }
            else if (estado.Equals(""))
            {



               
              
                txt2.Text = cbVendedor.Text;
                txt3.Text = cbCobrador.Text;
                txt1.Text = cbPrueba.Text;
                txt4.Text = cmbEstado.Text;
                 TextBox[] aDatos = { txt2, txt3, txtNit, txtBoxNombre, txtApellido, txtDireccion, txtTelefono, txtBoxCorreo, txt1,txt4};
                string sTabla = "cliente";
                cn.AsignarObjetos(sTabla, bPermiso, aDatos);

                //claseUsuario.funobtenerBitacora(claseUsuario.varibaleUsuario, "Insertar", sTabla);
                this.Close();
            }

            estado = "";
           
            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            btnNuevo.Enabled = true;
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
            btnRefrescar.Enabled = true;
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            estado = "editar";
            clasnegocio cnegocio = new clasnegocio();
        
            //txtNombre.Clear();
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;

              txtBoxNombre.Enabled = true;
            txtApellido.Enabled = true;
            txtBoxCorreo.Enabled = true;
            txtDireccion.Enabled = true;
            txtNit.Enabled = true;
            txt3.Enabled = true;
            txtDireccion.Enabled = true;
            txtTelefono.Enabled = true;
            txt4.Enabled = true;
            cbPrueba.Enabled =true;
            cbVendedor.Enabled = true;
            cbCobrador.Enabled = true;
            cmbEstado.Enabled = true;
            
        
       
        }

        private void button6_Click(object sender, EventArgs e)
        {
            estado = "eliminar";
            clasnegocio cn = new clasnegocio();
           
            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
            btnNuevo.Enabled = false;
            btnEditar.Enabled = false;
            btnEliminar.Enabled = false;
            btnRefrescar.Enabled = false;
           
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            clasnegocio cn = new clasnegocio();
          
          
            btnNuevo.Enabled = true;
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;

            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnImprimir.Enabled = false;
            btnRefrescar.Enabled = true;
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sCampoCodigo = "icod";
            string sCampoDescripcion = "vtipo";
            string query = "Select icod, vtipo from matipocliente where condicion='1'";
            frmFiltrado filtro = new frmFiltrado(query, sCampoCodigo, sCampoDescripcion); filtro.ShowDialog(this); int index = cbPrueba.FindString(filtro.funResultado()); cbPrueba.SelectedIndex = index;//Selecciona el item del combobox

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sCampoCodigo = "codVendedor";
            string sCampoDescripcion = "nombrevendedor";
            string query = "Select codVendedor, nombrevendedor from vendedor where condicion='1'";
            frmFiltrado filtro = new frmFiltrado(query, sCampoCodigo, sCampoDescripcion); filtro.ShowDialog(this); int index = cbVendedor.FindString(filtro.funResultado()); cbVendedor.SelectedIndex = index;//Selecciona el item del combobox

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            string sCampoCodigo = "codCobrador";
            string sCampoDescripcion = "nombre";
            string query = "Select codCobrador, nombre from cobrador where condicion='1'";
            frmFiltrado filtro = new frmFiltrado(query, sCampoCodigo, sCampoDescripcion); filtro.ShowDialog(this); int index = cbCobrador.FindString(filtro.funResultado()); cbCobrador.SelectedIndex = index;//Selecciona el item del combobox

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, "file://C:\\Clientes.chm");
        }
    }
}

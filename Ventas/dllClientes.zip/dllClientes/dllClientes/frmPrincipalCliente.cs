﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Navegador;
using ConexionODBC;
using System.Data.Odbc;

namespace dllClientes
{
    public partial class frmPrincipalCliente : Form
    {
        public frmPrincipalCliente()
        {
            InitializeComponent();
           funActualizarGrid();
        }

        private void frmPrincipalCliente_Load(object sender, EventArgs e)
        {
            this.Dock = DockStyle.Fill;
           // funActualizarGrid();
          
           

        }

        private void funActualizarGrid()
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistros("CLIENTE", "SELECT ncodcliente as ID,nombrecliente as NOMBRE,apellidocliente as APELLIDO, direccion as DIRECCION ,telefono as TELEFONO,correo as CORREO,saldoactual as SALDO,cargo as CARGO,abono as ABONO from CLIENTE", "consulta", grdUsuarios);


        }
        private void btnNuevo_Click(object sender, EventArgs e)
        {

            frmNuevoCliente temp2 = new frmNuevoCliente();
            temp2.WindowState = FormWindowState.Normal;


            temp2.Show();
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            //funActualizarGrid();
        }

        private void btnIrPrimero_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funPrimero(grdUsuarios);
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funAnterior(grdUsuarios);
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funSiguiente(grdUsuarios);
        }

        private void btnIrUltimo_Click(object sender, EventArgs e)
        {
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funUltimo(grdUsuarios);
        }

        private void grdUsuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void grdUsuarios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string cod = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[0].Value.ToString();
            string cobrador = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[1].Value.ToString();
            string vendedor = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[2].Value.ToString();
       
            string nombre = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[3].Value.ToString();
            string apellido = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[4].Value.ToString();
            string direccion = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[5].Value.ToString();
            string telefono = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[6].Value.ToString();
            string correo = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[7].Value.ToString();
            
            string estado = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[8].Value.ToString();
            //string nit = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[9].Value.ToString();
           
            
           // string saldoactual = grdUsuarios.Rows[grdUsuarios.CurrentCell.RowIndex].Cells[5].Value.ToString();
           
           
           
         

           
          
           
            // MessageBox.Show("esto lleva" + usuario + password + rol + estado + nombre);

            frmNuevoCliente temp = new frmNuevoCliente(cod,cobrador,vendedor,nombre,apellido,direccion,telefono,correo,estado);
            temp.Show();
            
        }

        private void txtBuscar_KeyUp(object sender, KeyEventArgs e)
        {
          string estado;
            estado = "ACTIVO";
            clasnegocio cnegocio = new clasnegocio();
            cnegocio.funconsultarRegistros("cliente", "select *from cliente where estado ='" +estado+"'","consulta", grdUsuarios);
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, "file://C:\\Clientes.chm");
        }
    }
}

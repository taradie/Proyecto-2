﻿namespace PROTOTIPO_C.C
{
    partial class frmMenuPrincipal
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenuPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cuentasCorrientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cobrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prestamosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pagosDeClientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deudasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pagoProveedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seguridadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresoDeEmpleadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pagoAEmpleadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.amortizacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prestamosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.seguridadToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proveedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empleadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seguridadToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.usuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bitacoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuracionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.monedaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.baseDeDatosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.idiomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cuentasCorrientesToolStripMenuItem,
            this.reportesToolStripMenuItem,
            this.seguridadToolStripMenuItem,
            this.seguridadToolStripMenuItem1,
            this.seguridadToolStripMenuItem2,
            this.configuracionToolStripMenuItem,
            this.ayudaToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // cuentasCorrientesToolStripMenuItem
            // 
            this.cuentasCorrientesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cobrosToolStripMenuItem,
            this.prestamosToolStripMenuItem,
            this.pagosDeClientesToolStripMenuItem});
            resources.ApplyResources(this.cuentasCorrientesToolStripMenuItem, "cuentasCorrientesToolStripMenuItem");
            this.cuentasCorrientesToolStripMenuItem.Name = "cuentasCorrientesToolStripMenuItem";
            this.cuentasCorrientesToolStripMenuItem.Click += new System.EventHandler(this.cuentasCorrientesToolStripMenuItem_Click);
            // 
            // cobrosToolStripMenuItem
            // 
            resources.ApplyResources(this.cobrosToolStripMenuItem, "cobrosToolStripMenuItem");
            this.cobrosToolStripMenuItem.Name = "cobrosToolStripMenuItem";
            this.cobrosToolStripMenuItem.Click += new System.EventHandler(this.cobrosToolStripMenuItem_Click);
            // 
            // prestamosToolStripMenuItem
            // 
            resources.ApplyResources(this.prestamosToolStripMenuItem, "prestamosToolStripMenuItem");
            this.prestamosToolStripMenuItem.Name = "prestamosToolStripMenuItem";
            this.prestamosToolStripMenuItem.Click += new System.EventHandler(this.prestamosToolStripMenuItem_Click);
            // 
            // pagosDeClientesToolStripMenuItem
            // 
            resources.ApplyResources(this.pagosDeClientesToolStripMenuItem, "pagosDeClientesToolStripMenuItem");
            this.pagosDeClientesToolStripMenuItem.Name = "pagosDeClientesToolStripMenuItem";
            this.pagosDeClientesToolStripMenuItem.Click += new System.EventHandler(this.pagosDeClientesToolStripMenuItem_Click);
            // 
            // reportesToolStripMenuItem
            // 
            this.reportesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clienteToolStripMenuItem,
            this.deudasToolStripMenuItem1,
            this.pagoProveedoresToolStripMenuItem});
            resources.ApplyResources(this.reportesToolStripMenuItem, "reportesToolStripMenuItem");
            this.reportesToolStripMenuItem.Name = "reportesToolStripMenuItem";
            // 
            // clienteToolStripMenuItem
            // 
            resources.ApplyResources(this.clienteToolStripMenuItem, "clienteToolStripMenuItem");
            this.clienteToolStripMenuItem.Name = "clienteToolStripMenuItem";
            this.clienteToolStripMenuItem.Click += new System.EventHandler(this.clienteToolStripMenuItem_Click);
            // 
            // deudasToolStripMenuItem1
            // 
            resources.ApplyResources(this.deudasToolStripMenuItem1, "deudasToolStripMenuItem1");
            this.deudasToolStripMenuItem1.Name = "deudasToolStripMenuItem1";
            this.deudasToolStripMenuItem1.Click += new System.EventHandler(this.deudasToolStripMenuItem1_Click);
            // 
            // pagoProveedoresToolStripMenuItem
            // 
            resources.ApplyResources(this.pagoProveedoresToolStripMenuItem, "pagoProveedoresToolStripMenuItem");
            this.pagoProveedoresToolStripMenuItem.Name = "pagoProveedoresToolStripMenuItem";
            this.pagoProveedoresToolStripMenuItem.Click += new System.EventHandler(this.pagoProveedoresToolStripMenuItem_Click);
            // 
            // seguridadToolStripMenuItem
            // 
            this.seguridadToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ingresoDeEmpleadosToolStripMenuItem,
            this.pagoAEmpleadosToolStripMenuItem,
            this.amortizacionesToolStripMenuItem,
            this.prestamosToolStripMenuItem1});
            resources.ApplyResources(this.seguridadToolStripMenuItem, "seguridadToolStripMenuItem");
            this.seguridadToolStripMenuItem.Name = "seguridadToolStripMenuItem";
            // 
            // ingresoDeEmpleadosToolStripMenuItem
            // 
            resources.ApplyResources(this.ingresoDeEmpleadosToolStripMenuItem, "ingresoDeEmpleadosToolStripMenuItem");
            this.ingresoDeEmpleadosToolStripMenuItem.Name = "ingresoDeEmpleadosToolStripMenuItem";
            // 
            // pagoAEmpleadosToolStripMenuItem
            // 
            resources.ApplyResources(this.pagoAEmpleadosToolStripMenuItem, "pagoAEmpleadosToolStripMenuItem");
            this.pagoAEmpleadosToolStripMenuItem.Name = "pagoAEmpleadosToolStripMenuItem";
            this.pagoAEmpleadosToolStripMenuItem.Click += new System.EventHandler(this.pagoAEmpleadosToolStripMenuItem_Click);
            // 
            // amortizacionesToolStripMenuItem
            // 
            this.amortizacionesToolStripMenuItem.Name = "amortizacionesToolStripMenuItem";
            resources.ApplyResources(this.amortizacionesToolStripMenuItem, "amortizacionesToolStripMenuItem");
            // 
            // prestamosToolStripMenuItem1
            // 
            resources.ApplyResources(this.prestamosToolStripMenuItem1, "prestamosToolStripMenuItem1");
            this.prestamosToolStripMenuItem1.Name = "prestamosToolStripMenuItem1";
            this.prestamosToolStripMenuItem1.Click += new System.EventHandler(this.prestamosToolStripMenuItem1_Click);
            // 
            // seguridadToolStripMenuItem1
            // 
            this.seguridadToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientesToolStripMenuItem,
            this.proveedoresToolStripMenuItem,
            this.empleadosToolStripMenuItem});
            resources.ApplyResources(this.seguridadToolStripMenuItem1, "seguridadToolStripMenuItem1");
            this.seguridadToolStripMenuItem1.Name = "seguridadToolStripMenuItem1";
            // 
            // clientesToolStripMenuItem
            // 
            resources.ApplyResources(this.clientesToolStripMenuItem, "clientesToolStripMenuItem");
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            // 
            // proveedoresToolStripMenuItem
            // 
            resources.ApplyResources(this.proveedoresToolStripMenuItem, "proveedoresToolStripMenuItem");
            this.proveedoresToolStripMenuItem.Name = "proveedoresToolStripMenuItem";
            // 
            // empleadosToolStripMenuItem
            // 
            resources.ApplyResources(this.empleadosToolStripMenuItem, "empleadosToolStripMenuItem");
            this.empleadosToolStripMenuItem.Name = "empleadosToolStripMenuItem";
            // 
            // seguridadToolStripMenuItem2
            // 
            this.seguridadToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usuariosToolStripMenuItem,
            this.bitacoraToolStripMenuItem});
            resources.ApplyResources(this.seguridadToolStripMenuItem2, "seguridadToolStripMenuItem2");
            this.seguridadToolStripMenuItem2.Name = "seguridadToolStripMenuItem2";
            // 
            // usuariosToolStripMenuItem
            // 
            this.usuariosToolStripMenuItem.Name = "usuariosToolStripMenuItem";
            resources.ApplyResources(this.usuariosToolStripMenuItem, "usuariosToolStripMenuItem");
            // 
            // bitacoraToolStripMenuItem
            // 
            this.bitacoraToolStripMenuItem.Name = "bitacoraToolStripMenuItem";
            resources.ApplyResources(this.bitacoraToolStripMenuItem, "bitacoraToolStripMenuItem");
            // 
            // configuracionToolStripMenuItem
            // 
            this.configuracionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.monedaToolStripMenuItem,
            this.baseDeDatosToolStripMenuItem,
            this.idiomaToolStripMenuItem,
            this.empresaToolStripMenuItem});
            resources.ApplyResources(this.configuracionToolStripMenuItem, "configuracionToolStripMenuItem");
            this.configuracionToolStripMenuItem.Name = "configuracionToolStripMenuItem";
            this.configuracionToolStripMenuItem.Click += new System.EventHandler(this.configuracionToolStripMenuItem_Click);
            // 
            // monedaToolStripMenuItem
            // 
            resources.ApplyResources(this.monedaToolStripMenuItem, "monedaToolStripMenuItem");
            this.monedaToolStripMenuItem.Name = "monedaToolStripMenuItem";
            this.monedaToolStripMenuItem.Click += new System.EventHandler(this.monedaToolStripMenuItem_Click);
            // 
            // baseDeDatosToolStripMenuItem
            // 
            resources.ApplyResources(this.baseDeDatosToolStripMenuItem, "baseDeDatosToolStripMenuItem");
            this.baseDeDatosToolStripMenuItem.Name = "baseDeDatosToolStripMenuItem";
            // 
            // idiomaToolStripMenuItem
            // 
            resources.ApplyResources(this.idiomaToolStripMenuItem, "idiomaToolStripMenuItem");
            this.idiomaToolStripMenuItem.Name = "idiomaToolStripMenuItem";
            this.idiomaToolStripMenuItem.Click += new System.EventHandler(this.idiomaToolStripMenuItem_Click);
            // 
            // empresaToolStripMenuItem
            // 
            resources.ApplyResources(this.empresaToolStripMenuItem, "empresaToolStripMenuItem");
            this.empresaToolStripMenuItem.Name = "empresaToolStripMenuItem";
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            resources.ApplyResources(this.ayudaToolStripMenuItem, "ayudaToolStripMenuItem");
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel3,
            this.toolStripSeparator1,
            this.toolStripLabel1,
            this.toolStripLabel2});
            resources.ApplyResources(this.toolStrip1, "toolStrip1");
            this.toolStrip1.Name = "toolStrip1";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            resources.ApplyResources(this.toolStripLabel3, "toolStripLabel3");
            this.toolStripLabel3.Click += new System.EventHandler(this.toolStripLabel3_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            resources.ApplyResources(this.toolStripLabel1, "toolStripLabel1");
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripLabel2.Name = "toolStripLabel2";
            resources.ApplyResources(this.toolStripLabel2, "toolStripLabel2");
            // 
            // frmMenuPrincipal
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMenuPrincipal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cobrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prestamosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deudasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem seguridadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pagosDeClientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pagoProveedoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresoDeEmpleadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pagoAEmpleadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem amortizacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prestamosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem seguridadToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem proveedoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empleadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seguridadToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem usuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bitacoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuracionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem monedaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem baseDeDatosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem idiomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empresaToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem cuentasCorrientesToolStripMenuItem;
    }
}


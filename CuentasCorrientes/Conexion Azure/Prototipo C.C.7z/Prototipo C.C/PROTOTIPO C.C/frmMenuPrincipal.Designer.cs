﻿namespace PROTOTIPO_C.C
{
    partial class frmMenuPrincipal
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenuPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MenuInicio = new System.Windows.Forms.ToolStripMenuItem();
            this.impresorasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conceptosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipoDePagoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cerrarSesionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cobradorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.webServiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuClientes = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresoCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facturasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuProveedores = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresoPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facturasPToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevaFacturaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuEmpleados = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresoEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prestamosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pagosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuReportes = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuConfiguracion = new System.Windows.Forms.ToolStripMenuItem();
            this.baseDeDatosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.idiomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuSeguridad = new System.Windows.Forms.ToolStripMenuItem();
            this.creacionDeUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bitacoraToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuAyuda = new System.Windows.Forms.ToolStripMenuItem();
            this.Impresoras = new System.Windows.Forms.ToolStripMenuItem();
            this.Multisistemas = new System.Windows.Forms.ToolStripMenuItem();
            this.Conceptos = new System.Windows.Forms.ToolStripMenuItem();
            this.CerrarSesion = new System.Windows.Forms.ToolStripMenuItem();
            this.Documentos = new System.Windows.Forms.ToolStripMenuItem();
            this.IngresoClientes = new System.Windows.Forms.ToolStripMenuItem();
            this.Facturas = new System.Windows.Forms.ToolStripMenuItem();
            this.IngresoProveedores = new System.Windows.Forms.ToolStripMenuItem();
            this.FacturasP = new System.Windows.Forms.ToolStripMenuItem();
            this.IngresoEmpleados = new System.Windows.Forms.ToolStripMenuItem();
            this.Prestamos = new System.Windows.Forms.ToolStripMenuItem();
            this.PagosEmpleados = new System.Windows.Forms.ToolStripMenuItem();
            this.Moneda = new System.Windows.Forms.ToolStripMenuItem();
            this.basededatos = new System.Windows.Forms.ToolStripMenuItem();
            this.idioma = new System.Windows.Forms.ToolStripMenuItem();
            this.empresa = new System.Windows.Forms.ToolStripMenuItem();
            this.usuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bitacoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuInicio,
            this.MenuClientes,
            this.MenuProveedores,
            this.MenuEmpleados,
            this.MenuReportes,
            this.MenuConfiguracion,
            this.MenuSeguridad,
            this.MenuAyuda});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // MenuInicio
            // 
            this.MenuInicio.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.impresorasToolStripMenuItem,
            this.sistemaToolStripMenuItem,
            this.conceptosToolStripMenuItem,
            this.tipoDePagoToolStripMenuItem,
            this.cerrarSesionToolStripMenuItem,
            this.cobradorToolStripMenuItem,
            this.webServiceToolStripMenuItem});
            this.MenuInicio.Name = "MenuInicio";
            resources.ApplyResources(this.MenuInicio, "MenuInicio");
            // 
            // impresorasToolStripMenuItem
            // 
            this.impresorasToolStripMenuItem.Name = "impresorasToolStripMenuItem";
            resources.ApplyResources(this.impresorasToolStripMenuItem, "impresorasToolStripMenuItem");
            // 
            // sistemaToolStripMenuItem
            // 
            this.sistemaToolStripMenuItem.Name = "sistemaToolStripMenuItem";
            resources.ApplyResources(this.sistemaToolStripMenuItem, "sistemaToolStripMenuItem");
            // 
            // conceptosToolStripMenuItem
            // 
            this.conceptosToolStripMenuItem.Name = "conceptosToolStripMenuItem";
            resources.ApplyResources(this.conceptosToolStripMenuItem, "conceptosToolStripMenuItem");
            this.conceptosToolStripMenuItem.Click += new System.EventHandler(this.conceptosToolStripMenuItem_Click);
            // 
            // tipoDePagoToolStripMenuItem
            // 
            this.tipoDePagoToolStripMenuItem.Name = "tipoDePagoToolStripMenuItem";
            resources.ApplyResources(this.tipoDePagoToolStripMenuItem, "tipoDePagoToolStripMenuItem");
            this.tipoDePagoToolStripMenuItem.Click += new System.EventHandler(this.tipoDePagoToolStripMenuItem_Click);
            // 
            // cerrarSesionToolStripMenuItem
            // 
            this.cerrarSesionToolStripMenuItem.Name = "cerrarSesionToolStripMenuItem";
            resources.ApplyResources(this.cerrarSesionToolStripMenuItem, "cerrarSesionToolStripMenuItem");
            this.cerrarSesionToolStripMenuItem.Click += new System.EventHandler(this.cerrarSesionToolStripMenuItem_Click_1);
            // 
            // cobradorToolStripMenuItem
            // 
            this.cobradorToolStripMenuItem.Name = "cobradorToolStripMenuItem";
            resources.ApplyResources(this.cobradorToolStripMenuItem, "cobradorToolStripMenuItem");
            this.cobradorToolStripMenuItem.Click += new System.EventHandler(this.cobradorToolStripMenuItem_Click);
            // 
            // webServiceToolStripMenuItem
            // 
            this.webServiceToolStripMenuItem.Name = "webServiceToolStripMenuItem";
            resources.ApplyResources(this.webServiceToolStripMenuItem, "webServiceToolStripMenuItem");
            this.webServiceToolStripMenuItem.Click += new System.EventHandler(this.webServiceToolStripMenuItem_Click);
            // 
            // MenuClientes
            // 
            this.MenuClientes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ingresoCToolStripMenuItem,
            this.facturasToolStripMenuItem});
            resources.ApplyResources(this.MenuClientes, "MenuClientes");
            this.MenuClientes.Name = "MenuClientes";
            this.MenuClientes.Click += new System.EventHandler(this.cuentasCorrientesToolStripMenuItem_Click);
            // 
            // ingresoCToolStripMenuItem
            // 
            resources.ApplyResources(this.ingresoCToolStripMenuItem, "ingresoCToolStripMenuItem");
            this.ingresoCToolStripMenuItem.Name = "ingresoCToolStripMenuItem";
            this.ingresoCToolStripMenuItem.Click += new System.EventHandler(this.ingresoCToolStripMenuItem_Click);
            // 
            // facturasToolStripMenuItem
            // 
            resources.ApplyResources(this.facturasToolStripMenuItem, "facturasToolStripMenuItem");
            this.facturasToolStripMenuItem.Name = "facturasToolStripMenuItem";
            this.facturasToolStripMenuItem.Click += new System.EventHandler(this.facturasToolStripMenuItem_Click);
            // 
            // MenuProveedores
            // 
            this.MenuProveedores.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ingresoPToolStripMenuItem,
            this.facturasPToolStripMenuItem1,
            this.nuevaFacturaToolStripMenuItem});
            resources.ApplyResources(this.MenuProveedores, "MenuProveedores");
            this.MenuProveedores.Name = "MenuProveedores";
            // 
            // ingresoPToolStripMenuItem
            // 
            resources.ApplyResources(this.ingresoPToolStripMenuItem, "ingresoPToolStripMenuItem");
            this.ingresoPToolStripMenuItem.Name = "ingresoPToolStripMenuItem";
            this.ingresoPToolStripMenuItem.Click += new System.EventHandler(this.ingresoPToolStripMenuItem_Click);
            // 
            // facturasPToolStripMenuItem1
            // 
            resources.ApplyResources(this.facturasPToolStripMenuItem1, "facturasPToolStripMenuItem1");
            this.facturasPToolStripMenuItem1.Name = "facturasPToolStripMenuItem1";
            this.facturasPToolStripMenuItem1.Click += new System.EventHandler(this.facturasPToolStripMenuItem1_Click);
            // 
            // nuevaFacturaToolStripMenuItem
            // 
            resources.ApplyResources(this.nuevaFacturaToolStripMenuItem, "nuevaFacturaToolStripMenuItem");
            this.nuevaFacturaToolStripMenuItem.Name = "nuevaFacturaToolStripMenuItem";
            this.nuevaFacturaToolStripMenuItem.Click += new System.EventHandler(this.nuevaFacturaToolStripMenuItem_Click);
            // 
            // MenuEmpleados
            // 
            this.MenuEmpleados.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ingresoEToolStripMenuItem,
            this.prestamosToolStripMenuItem,
            this.pagosToolStripMenuItem});
            resources.ApplyResources(this.MenuEmpleados, "MenuEmpleados");
            this.MenuEmpleados.Name = "MenuEmpleados";
            // 
            // ingresoEToolStripMenuItem
            // 
            resources.ApplyResources(this.ingresoEToolStripMenuItem, "ingresoEToolStripMenuItem");
            this.ingresoEToolStripMenuItem.Name = "ingresoEToolStripMenuItem";
            this.ingresoEToolStripMenuItem.Click += new System.EventHandler(this.ingresoEToolStripMenuItem_Click);
            // 
            // prestamosToolStripMenuItem
            // 
            resources.ApplyResources(this.prestamosToolStripMenuItem, "prestamosToolStripMenuItem");
            this.prestamosToolStripMenuItem.Name = "prestamosToolStripMenuItem";
            this.prestamosToolStripMenuItem.Click += new System.EventHandler(this.prestamosToolStripMenuItem_Click_1);
            // 
            // pagosToolStripMenuItem
            // 
            resources.ApplyResources(this.pagosToolStripMenuItem, "pagosToolStripMenuItem");
            this.pagosToolStripMenuItem.Name = "pagosToolStripMenuItem";
            this.pagosToolStripMenuItem.Click += new System.EventHandler(this.pagosToolStripMenuItem_Click);
            // 
            // MenuReportes
            // 
            resources.ApplyResources(this.MenuReportes, "MenuReportes");
            this.MenuReportes.Name = "MenuReportes";
            // 
            // MenuConfiguracion
            // 
            this.MenuConfiguracion.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.baseDeDatosToolStripMenuItem,
            this.idiomaToolStripMenuItem,
            this.empresaToolStripMenuItem});
            resources.ApplyResources(this.MenuConfiguracion, "MenuConfiguracion");
            this.MenuConfiguracion.Name = "MenuConfiguracion";
            this.MenuConfiguracion.Click += new System.EventHandler(this.configuracionToolStripMenuItem_Click);
            // 
            // baseDeDatosToolStripMenuItem
            // 
            resources.ApplyResources(this.baseDeDatosToolStripMenuItem, "baseDeDatosToolStripMenuItem");
            this.baseDeDatosToolStripMenuItem.Name = "baseDeDatosToolStripMenuItem";
            this.baseDeDatosToolStripMenuItem.Click += new System.EventHandler(this.baseDeDatosToolStripMenuItem_Click);
            // 
            // idiomaToolStripMenuItem
            // 
            resources.ApplyResources(this.idiomaToolStripMenuItem, "idiomaToolStripMenuItem");
            this.idiomaToolStripMenuItem.Name = "idiomaToolStripMenuItem";
            this.idiomaToolStripMenuItem.Click += new System.EventHandler(this.idiomaToolStripMenuItem_Click_1);
            // 
            // empresaToolStripMenuItem
            // 
            resources.ApplyResources(this.empresaToolStripMenuItem, "empresaToolStripMenuItem");
            this.empresaToolStripMenuItem.Name = "empresaToolStripMenuItem";
            this.empresaToolStripMenuItem.Click += new System.EventHandler(this.empresaToolStripMenuItem_Click_1);
            // 
            // MenuSeguridad
            // 
            this.MenuSeguridad.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.creacionDeUsuariosToolStripMenuItem,
            this.bitacoraToolStripMenuItem1});
            resources.ApplyResources(this.MenuSeguridad, "MenuSeguridad");
            this.MenuSeguridad.Name = "MenuSeguridad";
            // 
            // creacionDeUsuariosToolStripMenuItem
            // 
            this.creacionDeUsuariosToolStripMenuItem.Name = "creacionDeUsuariosToolStripMenuItem";
            resources.ApplyResources(this.creacionDeUsuariosToolStripMenuItem, "creacionDeUsuariosToolStripMenuItem");
            this.creacionDeUsuariosToolStripMenuItem.Click += new System.EventHandler(this.creacionDeUsuariosToolStripMenuItem_Click);
            // 
            // bitacoraToolStripMenuItem1
            // 
            this.bitacoraToolStripMenuItem1.Name = "bitacoraToolStripMenuItem1";
            resources.ApplyResources(this.bitacoraToolStripMenuItem1, "bitacoraToolStripMenuItem1");
            this.bitacoraToolStripMenuItem1.Click += new System.EventHandler(this.bitacoraToolStripMenuItem1_Click);
            // 
            // MenuAyuda
            // 
            this.MenuAyuda.Name = "MenuAyuda";
            resources.ApplyResources(this.MenuAyuda, "MenuAyuda");
            // 
            // Impresoras
            // 
            this.Impresoras.Name = "Impresoras";
            resources.ApplyResources(this.Impresoras, "Impresoras");
            // 
            // Multisistemas
            // 
            this.Multisistemas.Name = "Multisistemas";
            resources.ApplyResources(this.Multisistemas, "Multisistemas");
            // 
            // Conceptos
            // 
            this.Conceptos.Name = "Conceptos";
            resources.ApplyResources(this.Conceptos, "Conceptos");
            this.Conceptos.Click += new System.EventHandler(this.cerrarSesionToolStripMenuItem_Click);
            // 
            // CerrarSesion
            // 
            this.CerrarSesion.Name = "CerrarSesion";
            resources.ApplyResources(this.CerrarSesion, "CerrarSesion");
            // 
            // Documentos
            // 
            this.Documentos.Name = "Documentos";
            resources.ApplyResources(this.Documentos, "Documentos");
            this.Documentos.Click += new System.EventHandler(this.documentosToolStripMenuItem_Click);
            // 
            // IngresoClientes
            // 
            resources.ApplyResources(this.IngresoClientes, "IngresoClientes");
            this.IngresoClientes.Name = "IngresoClientes";
            this.IngresoClientes.Click += new System.EventHandler(this.cobrosToolStripMenuItem_Click);
            // 
            // Facturas
            // 
            resources.ApplyResources(this.Facturas, "Facturas");
            this.Facturas.Name = "Facturas";
            this.Facturas.Click += new System.EventHandler(this.prestamosToolStripMenuItem_Click);
            // 
            // IngresoProveedores
            // 
            resources.ApplyResources(this.IngresoProveedores, "IngresoProveedores");
            this.IngresoProveedores.Name = "IngresoProveedores";
            this.IngresoProveedores.Click += new System.EventHandler(this.clienteToolStripMenuItem_Click);
            // 
            // FacturasP
            // 
            resources.ApplyResources(this.FacturasP, "FacturasP");
            this.FacturasP.Name = "FacturasP";
            this.FacturasP.Click += new System.EventHandler(this.deudasToolStripMenuItem1_Click);
            // 
            // IngresoEmpleados
            // 
            resources.ApplyResources(this.IngresoEmpleados, "IngresoEmpleados");
            this.IngresoEmpleados.Name = "IngresoEmpleados";
            this.IngresoEmpleados.Click += new System.EventHandler(this.ingresoDeEmpleadosToolStripMenuItem_Click);
            // 
            // Prestamos
            // 
            resources.ApplyResources(this.Prestamos, "Prestamos");
            this.Prestamos.Name = "Prestamos";
            this.Prestamos.Click += new System.EventHandler(this.prestamosToolStripMenuItem1_Click);
            // 
            // PagosEmpleados
            // 
            resources.ApplyResources(this.PagosEmpleados, "PagosEmpleados");
            this.PagosEmpleados.Name = "PagosEmpleados";
            this.PagosEmpleados.Click += new System.EventHandler(this.pagoAEmpleadosToolStripMenuItem_Click);
            // 
            // Moneda
            // 
            resources.ApplyResources(this.Moneda, "Moneda");
            this.Moneda.Name = "Moneda";
            this.Moneda.Click += new System.EventHandler(this.monedaToolStripMenuItem_Click);
            // 
            // basededatos
            // 
            resources.ApplyResources(this.basededatos, "basededatos");
            this.basededatos.Name = "basededatos";
            // 
            // idioma
            // 
            resources.ApplyResources(this.idioma, "idioma");
            this.idioma.Name = "idioma";
            this.idioma.Click += new System.EventHandler(this.idiomaToolStripMenuItem_Click);
            // 
            // empresa
            // 
            resources.ApplyResources(this.empresa, "empresa");
            this.empresa.Name = "empresa";
            this.empresa.Click += new System.EventHandler(this.empresaToolStripMenuItem_Click);
            // 
            // usuariosToolStripMenuItem
            // 
            this.usuariosToolStripMenuItem.Name = "usuariosToolStripMenuItem";
            resources.ApplyResources(this.usuariosToolStripMenuItem, "usuariosToolStripMenuItem");
            // 
            // bitacoraToolStripMenuItem
            // 
            this.bitacoraToolStripMenuItem.Name = "bitacoraToolStripMenuItem";
            resources.ApplyResources(this.bitacoraToolStripMenuItem, "bitacoraToolStripMenuItem");
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel});
            resources.ApplyResources(this.toolStrip1, "toolStrip1");
            this.toolStrip1.Name = "toolStrip1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            resources.ApplyResources(this.toolStripStatusLabel2, "toolStripStatusLabel2");
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            resources.ApplyResources(this.toolStripStatusLabel, "toolStripStatusLabel");
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            resources.ApplyResources(this.toolStripLabel3, "toolStripLabel3");
            this.toolStripLabel3.Click += new System.EventHandler(this.toolStripLabel3_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            resources.ApplyResources(this.toolStripLabel1, "toolStripLabel1");
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripLabel2.Name = "toolStripLabel2";
            resources.ApplyResources(this.toolStripLabel2, "toolStripLabel2");
            // 
            // frmMenuPrincipal
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMenuPrincipal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMenuPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem IngresoClientes;
        private System.Windows.Forms.ToolStripMenuItem Facturas;
        private System.Windows.Forms.ToolStripMenuItem MenuProveedores;
        private System.Windows.Forms.ToolStripMenuItem IngresoProveedores;
        private System.Windows.Forms.ToolStripMenuItem FacturasP;
        private System.Windows.Forms.ToolStripMenuItem MenuEmpleados;
        private System.Windows.Forms.ToolStripMenuItem IngresoEmpleados;
        private System.Windows.Forms.ToolStripMenuItem PagosEmpleados;
        private System.Windows.Forms.ToolStripMenuItem Prestamos;
        private System.Windows.Forms.ToolStripMenuItem MenuReportes;
        private System.Windows.Forms.ToolStripMenuItem MenuSeguridad;
        private System.Windows.Forms.ToolStripMenuItem usuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bitacoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuConfiguracion;
        private System.Windows.Forms.ToolStripMenuItem Moneda;
        private System.Windows.Forms.ToolStripMenuItem basededatos;
        private System.Windows.Forms.ToolStripMenuItem idioma;
        private System.Windows.Forms.ToolStripMenuItem empresa;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripMenuItem MenuAyuda;
        public System.Windows.Forms.ToolStripMenuItem MenuClientes;
        private System.Windows.Forms.ToolStripMenuItem MenuInicio;
        private System.Windows.Forms.ToolStripMenuItem Impresoras;
        private System.Windows.Forms.ToolStripMenuItem Multisistemas;
        private System.Windows.Forms.ToolStripMenuItem Conceptos;
        private System.Windows.Forms.ToolStripMenuItem CerrarSesion;
        private System.Windows.Forms.ToolStripMenuItem Documentos;
        private System.Windows.Forms.ToolStripMenuItem impresorasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conceptosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tipoDePagoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cerrarSesionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresoCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facturasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresoPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facturasPToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ingresoEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prestamosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pagosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem baseDeDatosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem idiomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empresaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cobradorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem webServiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nuevaFacturaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem creacionDeUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bitacoraToolStripMenuItem1;
        public System.Windows.Forms.ToolStripLabel toolStripStatusLabel;
        public System.Windows.Forms.ToolStripLabel toolStripStatusLabel2;
    }
}


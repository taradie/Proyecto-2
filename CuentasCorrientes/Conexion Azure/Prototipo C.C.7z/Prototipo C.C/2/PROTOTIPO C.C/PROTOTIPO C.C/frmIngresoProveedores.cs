﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROTOTIPO_C.C
{
    public partial class frmIngresoProveedores : Form
    {
        public frmIngresoProveedores()
        {
            InitializeComponent();
        }
    }
}
